
The file pst-jtree-doc.tex is the main file, which is Texed.  It
calls other files as needed.  Instructions for updating nonlocal
references, the table of contents, and the index are given in the
pst-jtree-doc.tex.

