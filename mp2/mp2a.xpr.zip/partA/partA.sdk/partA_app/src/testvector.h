/*
 * testvector.h
 *
 *  Created on: Sep 22, 2015
 *      Author: thnguyn2
 */

#ifndef TESTVECTOR_H_
#define TESTVECTOR_H_
int num_test_vectors = 2;
char testvector[2][100]= {"The quick brown fox tried to jump over the fence.","He wasn't very successful, and has the scars to show."};
#endif /* TESTVECTOR_H_ */
